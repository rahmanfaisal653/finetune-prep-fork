import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import * as pdfParseModule from 'pdf-parse';
const pdfParse: any = (pdfParseModule as any).default || pdfParseModule;

interface DocumentChunkReq {
  id: string;
  docId: string;
  docName: string;
  chunkIndex: number;
  content: string;
}

interface DocumentReq {
  id: string;
  name: string;
  type: string;
  fullText: string;
  chunks: DocumentChunkReq[];
}

// Simple TF-IDF / Keyword matching function for RAG retrieval
function retrieveRelevantChunks(
  query: string,
  documents: DocumentReq[],
  topK = 5
) {
  const keywords = query
    .toLowerCase()
    .replace(/[^\w\s]/g, '')
    .split(/\s+/)
    .filter((w) => w.length > 2);

  const scoredChunks: {
    chunk: DocumentChunkReq;
    score: number;
    excerpt: string;
  }[] = [];

  for (const doc of documents) {
    if (!doc.chunks || doc.chunks.length === 0) continue;
    for (const chunk of doc.chunks) {
      const contentLower = chunk.content.toLowerCase();
      let matchCount = 0;

      for (const kw of keywords) {
        if (contentLower.includes(kw)) {
          matchCount += 1;
          // Extra weight if keyword appears multiple times
          const occurrences = (contentLower.match(new RegExp(kw, 'g')) || []).length;
          matchCount += occurrences * 0.2;
        }
      }

      // Exact phrase match bonus
      if (query.length > 4 && contentLower.includes(query.toLowerCase())) {
        matchCount += 5;
      }

      const score = keywords.length > 0 ? matchCount / keywords.length : 0.5;

      if (score > 0 || documents.length === 1) {
        // Excerpt generator
        const snippet = chunk.content.slice(0, 200).replace(/\n+/g, ' ') + '...';
        scoredChunks.push({
          chunk,
          score: Math.min(0.98, Math.max(0.4, Number(score.toFixed(2)))),
          excerpt: snippet,
        });
      }
    }
  }

  // Sort descending by score
  scoredChunks.sort((a, b) => b.score - a.score);

  // Take topK
  const selected = scoredChunks.slice(0, topK);

  // Fallback if no keywords matched: take first 3 chunks of active documents
  if (selected.length === 0 && documents.length > 0) {
    for (const doc of documents.slice(0, 2)) {
      for (const chunk of doc.chunks.slice(0, 2)) {
        selected.push({
          chunk,
          score: 0.65,
          excerpt: chunk.content.slice(0, 200).replace(/\n+/g, ' ') + '...',
        });
      }
    }
  }

  return selected;
}

// Initialize Gemini Client
function getGeminiClient(customApiKey?: string) {
  let key = customApiKey;
  if (!key || key.includes('xxxx') || key.startsWith('sk-') || key.trim().length < 10) {
    key = process.env.GEMINI_API_KEY;
  }
  if (!key) return null;
  return new GoogleGenAI({
    apiKey: key,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));

  // API Route: Healthcheck
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // API Route: RAG Chat Completion
  app.post('/api/rag/chat', async (req, res) => {
    try {
      const {
        message,
        documents = [],
        chatHistory = [],
        settings = {},
        targetDocId = null,
      } = req.body;

      if (!message || typeof message !== 'string') {
        res.status(400).json({ error: 'Message query string is required' });
        return;
      }

      // Filter docs if targetDocId specified
      const activeDocs: DocumentReq[] = targetDocId
        ? documents.filter((d: DocumentReq) => d.id === targetDocId)
        : documents;

      // 1. Retrieve top relevant chunks
      const retrieved = retrieveRelevantChunks(message, activeDocs, 5);

      const citations = retrieved.map((r) => ({
        docId: r.chunk.docId,
        docName: r.chunk.docName,
        chunkIndex: r.chunk.chunkIndex,
        excerpt: r.excerpt,
        score: r.score,
      }));

      // 2. Build context string
      const contextText = retrieved
        .map(
          (r, idx) =>
            `[Sumber ${idx + 1}: ${r.chunk.docName} (Bagian ${r.chunk.chunkIndex})]\n${r.chunk.content}`
        )
        .join('\n\n---\n\n');

      const systemInstruction = `Anda adalah "Asisten Pintar", asisten RAG cerdas berbahasa Indonesia.
Tugas Anda adalah membaca dan menjawab pertanyaan pengguna berdasarkan konteks dokumen referensi yang diberikan.

Pedoman Jawaban:
1. Gunakan Bahasa Indonesia yang ramah, sopan, dan jelas.
2. Jawab pertanyaan pengguna secara akurat berdasarkan konteks dokumen yang disediakan.
3. Sebutkan sumber dokumen (misal: "Berdasarkan [Nama Dokumen]...") jika relevan.
4. Format jawaban menggunakan Markdown yang rapi (gunakan bold, bullet points, numbered lists, atau kode jika perlu).
5. Jika informasi tidak ditemukan dalam konteks dokumen, jelaskan secara jujur bahwa informasi tidak terdapat dalam dokumen yang diunggah dan berikan bantuan umum terbaik.`;

      const promptWithContext = `Konteks Dokumen Referensi (RAG Context):
${contextText.length > 0 ? contextText : 'Tidak ada dokumen spesifik yang terhubung.'}

Pertanyaan Pengguna:
${message}`;

      let aiResponseText = '';

      // Try Gemini API
      let gemini = getGeminiClient(settings.apiKey);
      if (gemini) {
        try {
          const modelToUse = (settings.modelName && settings.modelName.includes('gemini'))
            ? settings.modelName
            : 'gemini-2.5-flash';

          const response = await gemini.models.generateContent({
            model: modelToUse,
            contents: promptWithContext,
            config: {
              systemInstruction,
              temperature: 0.3,
            },
          });

          aiResponseText = response.text || '';
        } catch (geminiError: any) {
          console.error('Gemini API Error with primary config:', geminiError?.message || geminiError);
          
          // Retry with system GEMINI_API_KEY and default model gemini-2.5-flash if available
          if (process.env.GEMINI_API_KEY) {
            try {
              const sysGemini = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
              const sysResp = await sysGemini.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: promptWithContext,
                config: { systemInstruction, temperature: 0.3 },
              });
              aiResponseText = sysResp.text || '';
            } catch (retryError) {
              console.error('Gemini API Error on system key retry:', retryError);
              aiResponseText = generateFallbackRAGAnswer(message, retrieved, documents);
            }
          } else {
            aiResponseText = generateFallbackRAGAnswer(message, retrieved, documents);
          }
        }
      } else {
        // Local synthesis fallback when API key is pending
        aiResponseText = generateFallbackRAGAnswer(message, retrieved, documents);
      }

      res.json({
        content: aiResponseText,
        citations,
        timestamp: new Date().toLocaleTimeString('id-ID', {
          hour: '2-digit',
          minute: '2-digit',
        }),
      });
    } catch (err: any) {
      console.error('RAG Chat endpoint error:', err);
      res.status(500).json({ error: err?.message || 'Failed to process RAG chat request' });
    }
  });

  // API Route: Process uploaded document file
  app.post('/api/rag/process-file', async (req, res) => {
    try {
      const { fileName, fileType, fileBase64, rawText } = req.body;

      let extractedText = rawText || '';

      if (fileBase64 && fileType === 'pdf') {
        const buffer = Buffer.from(fileBase64, 'base64');
        const pdfData = await pdfParse(buffer);
        extractedText = pdfData.text;
      } else if (fileBase64 && (fileType === 'txt' || fileType === 'md' || fileType === 'ipynb')) {
        extractedText = Buffer.from(fileBase64, 'base64').toString('utf-8');
        if (fileType === 'ipynb') {
          try {
            const nb = JSON.parse(extractedText);
            const cells = nb.cells || [];
            extractedText = cells
              .map((c: any) => (Array.isArray(c.source) ? c.source.join('') : c.source || ''))
              .join('\n\n');
          } catch (e) {
            // keep raw if parse fails
          }
        }
      }

      if (!extractedText.trim()) {
        extractedText = `Dokumen ${fileName} berhasil diunggah dan siap di-scan untuk analisis RAG.`;
      }

      // Chunk text into ~300 word pieces
      const paragraphs = extractedText.split(/\n\s*\n/);
      const chunks: DocumentChunkReq[] = [];
      let currentChunk = '';
      let chunkIdx = 1;
      const docId = 'doc-' + Date.now() + '-' + Math.floor(Math.random() * 1000);

      for (const p of paragraphs) {
        if ((currentChunk + '\n' + p).length > 1000) {
          if (currentChunk.trim()) {
            chunks.push({
              id: `${docId}-chunk-${chunkIdx}`,
              docId,
              docName: fileName,
              chunkIndex: chunkIdx,
              content: currentChunk.trim(),
            });
            chunkIdx++;
          }
          currentChunk = p;
        } else {
          currentChunk += (currentChunk ? '\n\n' : '') + p;
        }
      }

      if (currentChunk.trim()) {
        chunks.push({
          id: `${docId}-chunk-${chunkIdx}`,
          docId,
          docName: fileName,
          chunkIndex: chunkIdx,
          content: currentChunk.trim(),
        });
      }

      res.json({
        id: docId,
        name: fileName,
        type: fileType || 'pdf',
        size: extractedText.length * 2,
        chunkCount: chunks.length,
        status: 'SIAP',
        uploadedAt: new Date().toISOString().slice(0, 16).replace('T', ' '),
        fullText: extractedText,
        chunks,
      });
    } catch (err: any) {
      console.error('Process file error:', err);
      res.status(500).json({ error: 'Failed to extract text from file: ' + err.message });
    }
  });

  // API Route: Scan folder
  app.post('/api/rag/scan-folder', (req, res) => {
    const { folderPath } = req.body;
    const pathName = folderPath || 'G:\\My Drive\\Colab Notebooks';

    // Simulate finding multiple documents in folder
    const scannedFiles = [
      {
        id: 'scanned-' + Date.now() + '-1',
        name: 'Analisis_Dataset_Model_AI.ipynb',
        type: 'ipynb',
        size: 320000,
        chunkCount: 28,
        status: 'SIAP',
        uploadedAt: new Date().toISOString().slice(0, 16).replace('T', ' '),
        folderPath: pathName,
        fullText: `Jupyter Notebook: Analisis Dataset Model AI\nCell 1: Import Pandas, Numpy, Scikit-Learn\nCell 2: Exploratory Data Analysis & Feature Engineering\nCell 3: Model Training dengan XGBoost & PyTorch Transformer.`,
        chunks: [
          {
            id: 'scanned-chunk-1',
            docId: 'scanned-1',
            docName: 'Analisis_Dataset_Model_AI.ipynb',
            chunkIndex: 1,
            content: `Notebook Data Science Colab: Analisis Dataset Model AI & Preprocessing Data Pipeline.`,
          },
        ],
      },
      {
        id: 'scanned-' + Date.now() + '-2',
        name: 'Panduan_Keamanan_Sistem_RAG.pdf',
        type: 'pdf',
        size: 512000,
        chunkCount: 42,
        status: 'SIAP',
        uploadedAt: new Date().toISOString().slice(0, 16).replace('T', ' '),
        folderPath: pathName,
        fullText: `Panduan Keamanan Sistem Retrieval-Augmented Generation (RAG):\n1. Prevent Vector Database Injection.\n2. Sanitize user queries against prompt injection.\n3. Encrypt chunk embeddings in transit and at rest.`,
        chunks: [
          {
            id: 'scanned-chunk-2',
            docId: 'scanned-2',
            docName: 'Panduan_Keamanan_Sistem_RAG.pdf',
            chunkIndex: 1,
            content: `Panduan Keamanan Sistem Retrieval-Augmented Generation (RAG): Proteksi prompt injection dan enkripsi database vektor.`,
          },
        ],
      },
    ];

    res.json({
      folderPath: pathName,
      scannedCount: scannedFiles.length,
      documents: scannedFiles,
    });
  });

  // Vite middleware or static serving
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server RAG running on http://localhost:${PORT}`);
  });
}

// Smart fallback answer generator when API key is offline or in client demo
function generateFallbackRAGAnswer(
  query: string,
  retrieved: any[],
  allDocs: any[]
): string {
  const qLower = query.toLowerCase();

  if (retrieved.length > 0) {
    const topDoc = retrieved[0].chunk.docName;
    const topExcerpt = retrieved[0].chunk.content;

    if (qLower.includes('ringkas') || qLower.includes('summary')) {
      return `Berikut adalah ringkasan dari dokumen **${topDoc}** berdasarkan bagian yang relevan:\n\n` +
        `• **Tinjauan Utama**: Dokumen ini memuat informasi kunci mengenai "${topExcerpt.slice(0, 120)}...".\n` +
        `• **Poin Penting**: Terdiri dari struktur materi teknis yang dapat dianalisis secara mendalam melalui fitur Tanya Jawab RAG.\n` +
        `• **Rekomendasi**: Pengguna dapat mengajukan pertanyaan spesifik terkait istilah atau parameter yang terdapat dalam dokumen ini.`;
    }

    if (qLower.includes('poin') || qLower.includes('daftar')) {
      return `Berikut poin-poin penting yang diekstrak dari **${topDoc}**:\n\n` +
        `1. **Konteks Utama**: ${topExcerpt.slice(0, 150)}...\n` +
        `2. **Pencarian Relevan**: Sistem menemukan kecocokan sebesar ${(retrieved[0].score * 100).toFixed(0)}% pada bagian ${retrieved[0].chunk.chunkIndex}.\n` +
        `3. **Implementasi**: Pengetahuan dari bagian ini dapat langsung digunakan untuk pembelajaran atau referensi praktis.`;
    }

    return `Berdasarkan analisis dokumen **${topDoc}** (Bagian ${retrieved[0].chunk.chunkIndex}):\n\n` +
      `"${topExcerpt}"\n\n` +
      `**Penjelasan RAG**: Informasi di atas merupakan hasil ekstraksi paling relevan dengan pertanyaan Anda ("${query}"). Jika Anda membutuhkan detail lebih spesifik, silakan ajukan pertanyaan lanjutan!`;
  }

  return `Berdasarkan dokumen yang tersimpan di *Asisten Pintar*, tidak ditemukan kecocokan langsung untuk pertanyaan: "${query}".\n\nSilakan pastikan Anda telah mengunggah dokumen PDF, TXT, MD, atau IPYNB yang sesuai di menu **Dokumen Saya**.`;
}

startServer();
