import React, { useState, useEffect } from 'react';
import {
  INITIAL_DOCUMENTS,
  INITIAL_CHATS,
  INITIAL_SETTINGS,
  PROMPT_TEMPLATES,
} from './data/initialData';
import {
  DocumentItem,
  ChatSession,
  ChatMessage,
  AISettings,
  Citation,
  PromptTemplate,
} from './types';
import { Sidebar } from './components/Sidebar';
import { DokumenSayaView } from './components/DokumenSayaView';
import { TanyaJawabView } from './components/TanyaJawabView';
import { PengaturanView } from './components/PengaturanView';
import { TemplateTersimpanView } from './components/TemplateTersimpanView';
import { DocumentModal } from './components/DocumentModal';
import { SourceModal } from './components/SourceModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<'dokumen' | 'tanya' | 'pengaturan' | 'template'>('dokumen');
  const [documents, setDocuments] = useState<DocumentItem[]>(() => {
    const saved = localStorage.getItem('asisten_pintar_docs');
    if (!saved) return INITIAL_DOCUMENTS;
    try {
      const parsed = JSON.parse(saved);
      return parsed.filter((d: DocumentItem) => !['doc-1', 'doc-2', 'doc-3', 'doc-4'].includes(d.id));
    } catch {
      return INITIAL_DOCUMENTS;
    }
  });

  const [chatSessions, setChatSessions] = useState<ChatSession[]>(() => {
    const saved = localStorage.getItem('asisten_pintar_chats');
    if (!saved) return INITIAL_CHATS;
    try {
      const parsed = JSON.parse(saved);
      return parsed.filter((c: ChatSession) => c.id !== 'chat-1');
    } catch {
      return INITIAL_CHATS;
    }
  });

  const [templates, setTemplates] = useState<PromptTemplate[]>(() => {
    const saved = localStorage.getItem('asisten_pintar_templates');
    if (!saved) return PROMPT_TEMPLATES;
    try {
      const parsed = JSON.parse(saved);
      return parsed.filter((t: PromptTemplate) => !['tpl-1', 'tpl-2', 'tpl-3', 'tpl-4'].includes(t.id));
    } catch {
      return PROMPT_TEMPLATES;
    }
  });

  const [currentChatId, setCurrentChatId] = useState<string>(() => {
    return chatSessions.length > 0 ? chatSessions[0].id : '';
  });

  const [settings, setSettings] = useState<AISettings>(() => {
    const saved = localStorage.getItem('asisten_pintar_settings');
    return saved ? JSON.parse(saved) : INITIAL_SETTINGS;
  });

  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('asisten_pintar_dark') === 'true';
  });

  const [inspectDoc, setInspectDoc] = useState<DocumentItem | null>(null);
  const [inspectCitation, setInspectCitation] = useState<Citation | null>(null);
  const [isOpenMobile, setIsOpenMobile] = useState(false);

  // Sync localStorage
  useEffect(() => {
    localStorage.setItem('asisten_pintar_docs', JSON.stringify(documents));
  }, [documents]);

  useEffect(() => {
    localStorage.setItem('asisten_pintar_chats', JSON.stringify(chatSessions));
  }, [chatSessions]);

  useEffect(() => {
    localStorage.setItem('asisten_pintar_templates', JSON.stringify(templates));
  }, [templates]);

  useEffect(() => {
    localStorage.setItem('asisten_pintar_settings', JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('asisten_pintar_dark', String(darkMode));
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Handle New Chat Session
  const handleNewChat = () => {
    const newId = 'chat-' + Date.now();
    const newSession: ChatSession = {
      id: newId,
      title: 'Obrolan Baru',
      createdAt: new Date().toLocaleString('id-ID'),
      updatedAt: new Date().toLocaleString('id-ID'),
      messages: [],
    };
    setChatSessions([newSession, ...chatSessions]);
    setCurrentChatId(newId);
    setActiveTab('tanya');
  };

  // Handle Select Chat
  const handleSelectChat = (id: string) => {
    setCurrentChatId(id);
    setActiveTab('tanya');
  };

  // Handle Delete Chat
  const handleDeleteChat = (id: string) => {
    const updated = chatSessions.filter((c) => c.id !== id);
    setChatSessions(updated);
    if (currentChatId === id) {
      if (updated.length > 0) {
        setCurrentChatId(updated[0].id);
      } else {
        handleNewChat();
      }
    }
  };

  // Handle Rename Chat
  const handleRenameChat = (id: string, newTitle: string) => {
    setChatSessions((prev) =>
      prev.map((c) => (c.id === id ? { ...c, title: newTitle.trim() || 'Obrolan' } : c))
    );
  };

  // Handle Pin Chat
  const handlePinChat = (id: string) => {
    setChatSessions((prev) =>
      prev.map((c) => (c.id === id ? { ...c, pinned: !c.pinned } : c))
    );
  };

  // Handle Add Document
  const handleAddDocument = (newDoc: DocumentItem) => {
    setDocuments((prev) => [newDoc, ...prev]);
  };

  // Handle Delete Document
  const handleDeleteDocument = (id: string) => {
    setDocuments((prev) => prev.filter((d) => d.id !== id));
  };

  // Handle Scan Folder
  const handleScanFolder = async (folderPath: string) => {
    try {
      const res = await fetch('/api/rag/scan-folder', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ folderPath }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.documents && data.documents.length > 0) {
          setDocuments((prev) => [...data.documents, ...prev]);
        }
      }
    } catch (err) {
      console.error('Scan folder error:', err);
    }
  };

  // Handle Send Message in Chat (RAG AI Execution)
  const handleSendMessage = async (text: string, targetDocId?: string) => {
    let session = chatSessions.find((c) => c.id === currentChatId);

    if (!session) {
      const newId = 'chat-' + Date.now();
      session = {
        id: newId,
        title: text.slice(0, 24) || 'Obrolan Baru',
        createdAt: new Date().toLocaleString('id-ID'),
        updatedAt: new Date().toLocaleString('id-ID'),
        messages: [],
      };
      setChatSessions((prev) => [session!, ...prev]);
      setCurrentChatId(newId);
    }

    const userMsg: ChatMessage = {
      id: 'msg-u-' + Date.now(),
      chatId: session.id,
      role: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString('id-ID', {
        hour: '2-digit',
        minute: '2-digit',
      }),
    };

    // Update session title if first message
    const updatedTitle = session.messages.length === 0 ? text.slice(0, 24) : session.title;

    setChatSessions((prev) =>
      prev.map((c) =>
        c.id === session!.id
          ? {
              ...c,
              title: updatedTitle,
              updatedAt: new Date().toLocaleString('id-ID'),
              messages: [...c.messages, userMsg],
            }
          : c
      )
    );

    // Call RAG Chat Backend API
    try {
      const res = await fetch('/api/rag/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          documents,
          chatHistory: session.messages,
          settings,
          targetDocId,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const assistantMsg: ChatMessage = {
          id: 'msg-a-' + Date.now(),
          chatId: session.id,
          role: 'assistant',
          content: data.content,
          timestamp: data.timestamp || new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
          citations: data.citations || [],
        };

        setChatSessions((prev) =>
          prev.map((c) =>
            c.id === session!.id
              ? {
                  ...c,
                  updatedAt: new Date().toLocaleString('id-ID'),
                  messages: [...c.messages, assistantMsg],
                }
              : c
          )
        );
      }
    } catch (err) {
      console.error('RAG Chat API error:', err);
      const fallbackMsg: ChatMessage = {
        id: 'msg-a-err-' + Date.now(),
        chatId: session.id,
        role: 'assistant',
        content:
          'Maaf, terjadi kendala saat menghubungkan ke server RAG AI. Harap periksa koneksi atau pengaturan API key.',
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      };
      setChatSessions((prev) =>
        prev.map((c) =>
          c.id === session!.id ? { ...c, messages: [...c.messages, fallbackMsg] } : c
        )
      );
    }
  };

  const handleUseTemplate = (promptText: string) => {
    setActiveTab('tanya');
    handleSendMessage(promptText);
  };

  const handleSaveTemplate = (newTpl: PromptTemplate) => {
    setTemplates((prev) => [newTpl, ...prev]);
  };

  const handleDeleteTemplate = (id: string) => {
    setTemplates((prev) => prev.filter((t) => t.id !== id));
  };

  const currentChatSession = chatSessions.find((c) => c.id === currentChatId) || null;

  return (
    <div className="min-h-screen bg-[#f8f9fa] dark:bg-[#121216] text-[#191c1d] dark:text-gray-100 flex font-body antialiased transition-colors duration-300">
      {/* Mobile Top Header */}
      <div className="md:hidden fixed top-0 left-0 right-0 h-14 bg-[#f3f4f5] dark:bg-[#1e1e24] border-b border-[#cdc3d0] dark:border-gray-800 flex items-center justify-between px-4 z-20">
        <button
          onClick={() => setIsOpenMobile(true)}
          className="p-1.5 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-800 rounded-lg"
        >
          <span className="material-symbols-outlined">menu</span>
        </button>
        <div className="flex items-center gap-2">
          <span className="material-symbols-outlined text-[#6f5092] text-[20px]" style={{ fontVariationSettings: "'FILL' 1" }}>
            auto_awesome
          </span>
          <span className="font-headline font-bold text-[16px]">Asisten Pintar</span>
        </div>
        <button
          onClick={handleNewChat}
          className="p-1.5 text-[#6f5092] hover:bg-purple-100 dark:hover:bg-purple-950/40 rounded-lg"
        >
          <span className="material-symbols-outlined">add</span>
        </button>
      </div>

      {/* Sidebar Navigation */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        chatSessions={chatSessions}
        currentChatId={currentChatId}
        onSelectChat={handleSelectChat}
        onNewChat={handleNewChat}
        onDeleteChat={handleDeleteChat}
        onRenameChat={handleRenameChat}
        onPinChat={handlePinChat}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        isOpenMobile={isOpenMobile}
        setIsOpenMobile={setIsOpenMobile}
      />

      {/* Main Content View Container */}
      <div className="flex-1 flex flex-col md:ml-[280px] min-h-screen pt-14 md:pt-0 relative">
        {activeTab === 'dokumen' && (
          <DokumenSayaView
            documents={documents}
            onAddDocument={handleAddDocument}
            onDeleteDocument={handleDeleteDocument}
            onScanFolder={handleScanFolder}
            onSelectDocForInspection={(doc) => setInspectDoc(doc)}
            darkMode={darkMode}
          />
        )}

        {activeTab === 'tanya' && (
          <TanyaJawabView
            currentChat={currentChatSession}
            documents={documents}
            onSendMessage={handleSendMessage}
            onInspectCitation={(cite) => setInspectCitation(cite)}
            onSaveTemplate={handleSaveTemplate}
            darkMode={darkMode}
          />
        )}

        {activeTab === 'pengaturan' && (
          <PengaturanView
            settings={settings}
            onSaveSettings={(newSettings) => setSettings(newSettings)}
            darkMode={darkMode}
          />
        )}

        {activeTab === 'template' && (
          <TemplateTersimpanView
            templates={templates}
            onUseTemplate={handleUseTemplate}
            onDeleteTemplate={handleDeleteTemplate}
            darkMode={darkMode}
          />
        )}
      </div>

      {/* Inspection Modals */}
      <DocumentModal
        doc={inspectDoc}
        onClose={() => setInspectDoc(null)}
        onAskAboutDoc={(docId, docName) => {
          setActiveTab('tanya');
          handleSendMessage(
            `Jelaskan detail dan isi penting dari dokumen ${docName}.`,
            docId
          );
        }}
      />

      <SourceModal
        citation={inspectCitation}
        onClose={() => setInspectCitation(null)}
      />
    </div>
  );
}
