import React, { useState } from 'react';
import { DocumentItem } from '../types';

interface DokumenSayaViewProps {
  documents: DocumentItem[];
  onAddDocument: (doc: DocumentItem) => void;
  onDeleteDocument: (id: string) => void;
  onScanFolder: (folderPath: string) => void;
  onSelectDocForInspection: (doc: DocumentItem) => void;
  darkMode: boolean;
}

export const DokumenSayaView: React.FC<DokumenSayaViewProps> = ({
  documents,
  onAddDocument,
  onDeleteDocument,
  onScanFolder,
  onSelectDocForInspection,
  darkMode,
}) => {
  const [folderPathInput, setFolderPathInput] = useState('G:\\My Drive\\Colab Notebooks');
  const [isUploading, setIsUploading] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [dragOver, setDragOver] = useState(false);

  const handleScanClick = async () => {
    setIsScanning(true);
    try {
      await onScanFolder(folderPathInput);
    } catch (e) {
      console.error(e);
    } finally {
      setIsScanning(false);
    }
  };

  const handleFileUpload = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setIsUploading(true);

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const name = file.name;
      const typeExt = name.split('.').pop()?.toLowerCase() || 'txt';
      const fileType = typeExt === 'pdf' ? 'pdf' : typeExt === 'ipynb' ? 'ipynb' : typeExt === 'md' ? 'md' : 'txt';

      const reader = new FileReader();

      if (fileType === 'pdf') {
        reader.readAsDataURL(file);
        reader.onload = async () => {
          const base64 = (reader.result as string).split(',')[1];
          await processFileServer(name, fileType, base64, '');
        };
      } else {
        reader.readAsText(file);
        reader.onload = async () => {
          const text = reader.result as string;
          await processFileServer(name, fileType, '', text);
        };
      }
    }
    setIsUploading(false);
  };

  const processFileServer = async (
    fileName: string,
    fileType: string,
    fileBase64: string,
    rawText: string
  ) => {
    try {
      const res = await fetch('/api/rag/process-file', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fileName, fileType, fileBase64, rawText }),
      });
      if (res.ok) {
        const doc: DocumentItem = await res.json();
        onAddDocument(doc);
      }
    } catch (err) {
      console.error('File process error:', err);
    }
  };

  const escapeHtml = (str: string) =>
    str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');

  const handleOpenOriginalDoc = (doc: DocumentItem) => {
    const newWindow = window.open('', '_blank');
    if (newWindow) {
      newWindow.document.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>${escapeHtml(doc.name)}</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
              body {
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
                margin: 0;
                padding: 24px;
                background-color: #f8fafc;
                color: #0f172a;
                line-height: 1.6;
              }
              header {
                border-bottom: 1px solid #cbd5e1;
                padding-bottom: 16px;
                margin-bottom: 24px;
                display: flex;
                justify-content: space-between;
                align-items: center;
              }
              h1 {
                margin: 0;
                font-size: 20px;
                color: #0f172a;
              }
              .badge {
                background: #e2e8f0;
                color: #334155;
                font-size: 12px;
                font-weight: 600;
                padding: 4px 10px;
                border-radius: 9999px;
                text-transform: uppercase;
              }
              pre {
                background: #ffffff;
                padding: 20px;
                border-radius: 8px;
                border: 1px solid #cbd5e1;
                white-space: pre-wrap;
                word-break: break-word;
                font-family: ui-monospace, SFMono-Regular, Consolas, monospace;
                font-size: 14px;
                box-shadow: 0 1px 3px rgba(0,0,0,0.05);
              }
            </style>
          </head>
          <body>
            <header>
              <h1>${escapeHtml(doc.name)}</h1>
              <span class="badge">${escapeHtml(doc.type)}</span>
            </header>
            <pre>${escapeHtml(doc.fullText || 'Dokumen kosong.')}</pre>
          </body>
        </html>
      `);
      newWindow.document.close();
    }
  };

  return (
    <div className="flex-1 p-4 md:p-8 max-w-[1280px] mx-auto w-full pt-6 pb-20">
      {/* Page Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <span
            className="material-symbols-outlined text-[32px] text-[#6f5092] dark:text-[#d8b4fe]"
            style={{ fontVariationSettings: "'FILL' 1" }}
          >
            description
          </span>
          <h2 className="font-headline text-[28px] md:text-[32px] font-bold text-[#191c1d] dark:text-gray-100">
            Dokumen Saya
          </h2>
        </div>
      </div>

      {/* Upper Section: Scan Folder Card */}
      <div className="mb-10">
        <div className="bg-white dark:bg-[#1e1e24] border border-[#cdc3d0] dark:border-gray-800 rounded-xl p-5 md:p-6 shadow-sm relative overflow-hidden">
          <div>
            <div className="flex items-start gap-4 mb-4 relative z-10">
              <div className="w-12 h-12 rounded-xl bg-[#d8b4fe] text-[#604283] flex items-center justify-center shrink-0">
                <span
                  className="material-symbols-outlined text-[26px]"
                  style={{ fontVariationSettings: "'FILL' 1" }}
                >
                  folder
                </span>
              </div>
              <div>
                <h3 className="font-headline text-[20px] font-bold text-[#191c1d] dark:text-gray-100">
                  Scan Folder Otomatis
                </h3>
              </div>
            </div>

            <div className="mt-4 relative z-10">
              <label className="font-body text-[12px] font-semibold text-[#191c1d] dark:text-gray-300 flex items-center gap-1.5 mb-2">
                <span
                  className="material-symbols-outlined text-[16px] text-[#f59e0b]"
                  style={{ fontVariationSettings: "'FILL' 1" }}
                >
                  folder
                </span>
                Path Folder
              </label>

              <div className="flex gap-3 w-full">
                <input
                  type="text"
                  value={folderPathInput}
                  onChange={(e) => setFolderPathInput(e.target.value)}
                  className="flex-1 bg-[#f3f4f5] dark:bg-[#2e3132] border border-[#cdc3d0] dark:border-gray-700 rounded-lg px-3.5 py-2 font-body text-[14px] text-[#191c1d] dark:text-gray-100 focus:outline-none focus:border-[#6f5092]"
                  placeholder="Path folder..."
                />
                <button
                  onClick={handleScanClick}
                  disabled={isScanning}
                  className="bg-[#FFD54F] hover:opacity-90 text-[#29074a] px-5 py-2 rounded-lg font-body text-[14px] font-semibold transition-colors flex items-center justify-center gap-2 whitespace-nowrap shadow-sm cursor-pointer disabled:opacity-50"
                  title="Scan folder"
                >
                  <span className="material-symbols-outlined text-[20px]">
                    {isScanning ? 'sync' : 'search'}
                  </span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Documents Grid Section */}
      <div>
        <div className="flex items-center justify-between mb-5">
          <h3 className="font-headline text-[20px] font-bold text-[#191c1d] dark:text-gray-100">
            Dokumen yang Tersimpan
          </h3>
          <span className="bg-[#e9d5ff] dark:bg-[#4f4062] text-[#6a5a7e] dark:text-[#eddcff] px-3 py-1 rounded-full font-body text-[12px] font-semibold">
            {documents.length} dokumen
          </span>
        </div>

        {documents.length === 0 ? (
          <div className="bg-white dark:bg-[#1e1e24] border border-[#cdc3d0] dark:border-gray-800 rounded-xl p-8 text-center">
            <span className="material-symbols-outlined text-[48px] text-[#cdc3d0] mb-2">
              folder_off
            </span>
            <p className="font-body text-[15px] font-semibold text-[#191c1d] dark:text-gray-200">
              Belum ada dokumen yang diunggah.
            </p>
            <p className="font-body text-[13px] text-[#4a454f] dark:text-gray-400 mt-1">
              Gunakan tombol "Scan Folder Otomatis" untuk mengimpor materi belajar Anda.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {documents.map((doc) => (
              <div
                key={doc.id}
                className="bg-white dark:bg-[#1e1e24] border border-[#cdc3d0] dark:border-gray-800 hover:border-[#6f5092] dark:hover:border-[#d8b4fe] rounded-xl p-4 shadow-sm hover:shadow-md transition-all group flex items-center justify-between gap-3 overflow-hidden"
              >
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <div className="w-12 h-12 rounded-xl bg-[#d8b4fe]/20 text-[#6f5092] dark:text-[#d8b4fe] flex items-center justify-center shrink-0">
                    <span className="material-symbols-outlined text-[28px]">
                      {doc.type === 'pdf'
                        ? 'picture_as_pdf'
                        : doc.type === 'ipynb'
                        ? 'code'
                        : doc.type === 'md'
                        ? 'article'
                        : 'description'}
                    </span>
                  </div>

                  <div className="min-w-0 flex-1">
                    <h4 className="font-body text-[15px] font-semibold text-[#191c1d] dark:text-gray-100 truncate" title={doc.name}>
                      {doc.name}
                    </h4>
                  </div>
                </div>

                <button
                  onClick={() => handleOpenOriginalDoc(doc)}
                  title="Buka Dokumen Asli"
                  className="w-8 h-8 rounded-lg bg-gray-100 dark:bg-gray-800 hover:bg-[#d8b4fe]/30 text-[#4a454f] dark:text-gray-300 hover:text-[#6f5092] dark:hover:text-[#d8b4fe] transition-colors flex items-center justify-center shrink-0 cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[18px]">arrow_outward</span>
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
