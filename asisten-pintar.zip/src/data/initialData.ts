import { DocumentItem, ChatSession, AISettings, PromptTemplate } from '../types';

export const INITIAL_DOCUMENTS: DocumentItem[] = [];

export const INITIAL_CHATS: ChatSession[] = [];

export const INITIAL_SETTINGS: AISettings = {
  serverUrl: 'https://generativelanguage.googleapis.com',
  modelName: 'gemini-2.5-flash',
  apiKey: '',
  googleDriveConnected: false
};

export const PROMPT_TEMPLATES: PromptTemplate[] = [];

